document.getElementById("startButton").addEventListener("click", startConversation);

function startConversation() {
    let name = prompt("What should I call you?");
    
    // If no name is entered, default to "Dre"
    if (!name) {
        name = "Dre";
    }
    
    const isOkay = askYesNo(`Hi, ${name}! Are you okay?`);
    
    if (isOkay) {
        const sure = askYesNo("Are you sure?");
        
        if (sure) {
            alert("Stay strong! You’re doing amazing. Keep going! I'M PROUD OF YOU! PADAYON!");
        } else {
            alert("It’s normal not to be okay all the time. I hope things start to lighten up for you soon. But while you’re working through whatever’s weighing you down, please be kind to yourself.");
            showMoreAdviceAndNotes(); // Show advice and allow for notes
        }
    } else {
        showMoreAdviceAndNotes(); // Show advice and allow for notes if they aren't okay
    }
    
    document.getElementById("endMessage").classList.remove("hidden");
}

function askYesNo(question) {
    const response = prompt(`${question} (Type 'Yes' or 'No')`);
    return response && response.toLowerCase() === "yes";
}

function showMoreAdviceAndNotes(name) {
    const advices = [
        "Take a deep breath; everything will be fine.",
        "You are stronger than you think.",
        "It's okay to take a break and ask for help.",
        "Remember, tough times don't last, but tough people do!",
        "You’re capable of amazing things."
    ];

    // Show one random piece of advice
    const randomAdvice = advices[Math.floor(Math.random() * advices.length)];
    alert(randomAdvice);

    // After showing the advice, give the user a chance to express their feelings
    let notes = prompt("If you'd like, feel free to express your feelings or thoughts here. I'm listening:");

    if (notes) {
        alert("Thank you for sharing. Remember, expressing how you feel can help ease your mind.");
    } else {
        alert("It's okay if you don't feel like sharing right now. Just take your time.");
    }

    // Now, call the giveMotivation function
    giveMotivation(name);
}

function giveMotivation(name) {
    const advices = [
        "Take it one step at a time.",
        "Remember, it's okay to rest.",
        "You are stronger than you think.",
        "Believe in yourself, you can do this.",
        "Every day is a new opportunity to grow.",
        "Focus on progress, not perfection.",
        "You are loved and appreciated.",
        "Challenges are what make life interesting.",
    "Take a deep breath; everything will be fine.",
    "You are stronger than you think.",
    "It's okay to take a break and ask for help.",
    "Don’t be afraid to take a break when you need to.",
    "Believe in yourself, you’ve got this.",
    "Every step forward is progress, no matter how small.",
    "You are doing the best you can, and that’s enough.",
    "It's okay to ask for help; you're not alone.",
    "You’ve faced challenges before and you can overcome this too.",
    "Be kind to yourself; you’re doing your best.",
    "It's okay to not have all the answers right now.",
    "You are enough just as you are.",
    "Focus on one thing at a time, and you'll get through it.",
    "Small victories matter. Celebrate them.",
    "You don’t have to be perfect, you just need to keep going.",
    "The challenges you're facing are opportunities to grow.",
    "You’ve made it through every tough day before—this is no different.",
    "It’s okay to rest and recharge; you’ll come back stronger.",
    "You've made it this far and I'm so proud of you.",
    "Trust God and keep the faith. He’s got you.",
    "You’re doing better than you think, keep pushing.",
    "Hindi mo kailangang magmadali, one step at a time lang.",
    "Lahat ng pinagdadaanan mo ay may dahilan. Just keep going."
];

    // Show each advice once, without a loop
    alert(advices[0]);
    alert(advices[1]);
    alert(advices[2]);
    alert(advices[3]);
    alert(advices[4]);
    alert(advices[5]);
    alert(advices[6]);
    alert(advices[7]);
    alert(advices[8]);
    alert(advices[9]);
    alert(advices[10]);
    alert(advices[11]);
    alert(advices[12]);
    alert(advices[13]);
    alert(advices[14]);
    alert(advices[15]);
    alert(advices[16]);
    alert(advices[17]);
    alert(advices[18]);
    alert(advices[19]);
    alert(advices[20]);
    alert(advices[21]);
    alert(advices[22]);

    // Show the final motivation
    alert(`${name}, I'M ALWAYS PROUD OF YOU! PADAYON!`);
}
